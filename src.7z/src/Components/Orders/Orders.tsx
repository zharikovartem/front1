import { formatCountdown } from 'antd/lib/statistic/utils'
import React from 'react'
import { OrdersPropsType } from './OrdersContainer'

export type OwnOrdersPropsType = {}
const Orders: React.FC<OrdersPropsType> = (props) => {
    return(
        <div>Orders</div>
    )
}

export default Orders